// DynamicPrefetcher.h
#ifndef DYNAMICPREFETCHER_H
#define DYNAMICPREFETCHER_H

#include "BaseFetcher.h"

class DynamicPrefetcher : public BaseFetcher {
private:
    // Attributes specific to adaptive fetching
    uint64_t dynamicHistoryBufferSize;

public:
    // Constructor to initialize history buffer size
    DynamicPrefetcher(uint64_t size = 0) : dynamicHistoryBufferSize(size){}

    void Prefetching(uint64_t address, uint64_t PrefetchSize)  { 
        
        lastFetchedAddress = address;
        dynamicBuffer.push_back(lastFetchedAddress);

        // Keep only the last 8 elements
        while (dynamicBuffer.size() > dynamicHistoryBufferSize) {
            dynamicBuffer.erase(dynamicBuffer.begin());
        }
        std::cout << std::endl;
        // Clear the predictedAddresses vector before populating it again
        predictedAddresses.clear();
        
        for (int j = 0; j < PrefetchSize; j++) {
            uint64_t predictedAddress = ComputeNextAddress();
            predictedAddresses.push_back(predictedAddress);
            lastFetchedAddress = predictedAddress;
        }
        
    }

    uint64_t ComputeNextAddress() override {
        uint64_t predictedAddress = lastFetchedAddress + PredictOffset();
        return predictedAddress;

    }

    uint64_t PredictOffset() const override {
        uint64_t dynamicStride = 0;

        if (dynamicBuffer.size() > 1) {
            uint64_t sumOfDifferences = 0;
            for (uint64_t i = 1; i < dynamicBuffer.size(); ++i) {
                sumOfDifferences += dynamicBuffer[i] - dynamicBuffer[i - 1];
            }
            // Calculate the average
            dynamicStride = sumOfDifferences / (dynamicBuffer.size() - 1);
        }
        return dynamicStride;
    }


    // Implement other virtual functions declared in BaseFetcher
    std::string GetPrefetcherType() const override {
        return "Dynamic"; // Replace with an appropriate description
    }


    ~DynamicPrefetcher() override = default;
};

#endif // DYNAMICPREFETCHER_H
