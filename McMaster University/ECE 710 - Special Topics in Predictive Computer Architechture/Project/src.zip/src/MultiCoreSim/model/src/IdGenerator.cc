#include "../header/IdGenerator.h"

int IdGenerator::reqId = 1;

