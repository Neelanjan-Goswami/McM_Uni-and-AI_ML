#ifndef ALLOC_SETTING_H
#define ALLOC_SETTING_H
// comment out the below line for alloc-on-refill
#define ALLOC_ON_MISS
#endif
