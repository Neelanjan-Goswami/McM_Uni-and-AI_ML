// StaticPrefetcher.h
#ifndef STATICPREFETCHER_H
#define STATICPREFETCHER_H

#include "BaseFetcher.h"

class StaticPrefetcher : public BaseFetcher {
private:
    // Attributes specific to predictive fetching
    uint64_t prefetchDistance;

public:
    // Constructor with a default value for prefetch distance
    StaticPrefetcher(uint64_t distance = 0) : prefetchDistance(distance) {}

    void Prefetching(uint64_t address, uint64_t PrefetchSize) override {

        lastFetchedAddress = address;

        //std::cerr << "Static address: " << address << "\n";

        // Clear the predictedAddresses vector before populating it again
        predictedAddresses.clear();
        
        for (int j = 0; j < PrefetchSize; j++) {
            uint64_t predictedAddress = ComputeNextAddress();
            predictedAddresses.push_back(predictedAddress);
            lastFetchedAddress = predictedAddress;
        }
        
    }

    uint64_t ComputeNextAddress() override {
        uint64_t predictedAddress = lastFetchedAddress + PredictOffset();
        return predictedAddress;
    }

    uint64_t PredictOffset() const override {
        return prefetchDistance;
    }

    std::string GetPrefetcherType() const override {
        return "Static"; // Replace with an appropriate description
    }


    ~StaticPrefetcher() override = default;
};

#endif // STATICPREFETCHER_H
