// BaseFetcher.h
#ifndef BASEFETCHER_H
#define BASEFETCHER_H

#include <iostream>

class BaseFetcher {
protected:
    uint64_t lastFetchedAddress = 0;
    std::vector<uint64_t> predictedAddresses;
    std::vector<uint64_t> dynamicBuffer;

public:
    // Virtual function to get the type of the prefetcher
    virtual std::string GetPrefetcherType() const = 0;

    virtual void Prefetching(uint64_t address, uint64_t PrefetchSize) = 0;
    virtual uint64_t ComputeNextAddress() = 0;
    virtual uint64_t PredictOffset() const = 0;

    // Public getter for predictedAddresses
    const std::vector<uint64_t>& GetPredictedAddresses() const {
        return predictedAddresses;
    }

    virtual ~BaseFetcher() = default;
};

#endif // BASEFETCHER_H
